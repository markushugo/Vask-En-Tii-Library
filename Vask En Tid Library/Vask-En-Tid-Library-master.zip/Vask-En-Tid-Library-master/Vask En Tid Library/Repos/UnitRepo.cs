﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vask_En_Tid_Library.IRepos;
using Vask_En_Tid_Library.Models;

namespace Vask_En_Tid_Library.Repos
{
    public class UnitRepo : IUnitRepo
    {
        public void CreateUnit(int unitId)
        {
            
        }
        public void DeleteUnit(int unitId)
        {
            
        }
        public void GetAllUnits(int unitId)
        {
          
        }
        public void UpdateUnit(int unitId)
        {
        }
    }
}
