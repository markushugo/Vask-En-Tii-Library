﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vask_En_Tid_Library.IRepos;
using Vask_En_Tid_Library.Models;

namespace Vask_En_Tid_Library.Repos
{
    public class TimeslotRepo : ITimeslotRepo
    {
        public void ShowAvailableTimeslots(int id)
        {
            
        }
           
    }
}
